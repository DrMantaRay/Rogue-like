#include <stdio.h>
#include <ncurses.h>
#include "rogue.h"
#include <stdlib.h>
#include <time.h>


